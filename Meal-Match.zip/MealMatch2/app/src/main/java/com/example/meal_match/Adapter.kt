package com.example.meal_match

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class Adapter(private val meals:List<Meals>): RecyclerView.Adapter<Adapter.MealViewHolder>() {


    // This method is called by the RecyclerView to create a new ViewHolder object.
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val itemView = inflater.inflate(R.layout.food_template, parent, false)
        return MealViewHolder(itemView)
    }

    //returns the number of items in the meals list.
    override fun getItemCount(): Int =meals.size

    // This method is called by the RecyclerView to bind data to the views in a ViewHolder.
    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        val meal=meals[position]
        holder.bind(meal)
    }

    // These are the views that will be used to display information about the meal.
    class MealViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        private val txtMealName=itemView.findViewById<TextView>(R.id.txt_db_name)
        private val txtMealCategory=itemView.findViewById<TextView>(R.id.txt_db_category)
        private val txtMealArea=itemView.findViewById<TextView>(R.id.txt_db_area)
        private val txtMealTags=itemView.findViewById<TextView>(R.id.txt_db_tag)
        private val txtMealYoutube=itemView.findViewById<TextView>(R.id.txt_db_youtube)
        private val imgMeal=itemView.findViewById<ImageView>(R.id.img_dm)

        // This is a default bitmap that will be used if the image download fails.
        private var bitmap: Bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8)


        //bind method uses coroutines to download the image of the meal from url provide
        @SuppressLint("SetTextI18n")
        fun bind(meal: Meals) {
            txtMealName.text = meal.Meal
            txtMealCategory.text = "Category - ${meal.Category}"
            txtMealArea.text = "Area - ${meal.Area}"
            txtMealTags.text = "Tags - ${meal.Tags}"
            txtMealYoutube.text = "YouTube- ${meal.Youtube}\n"

            // Get the URL for the meal thumbnail image
            val url = meal.MealThumb

            if (!url.isNullOrEmpty()) { // Check if the URL is not null or empty
                runBlocking {
                    launch {
                        withContext(Dispatchers.IO) {
                            try {
                                val urlConnection = URL(url).openConnection() as HttpURLConnection
                                val input = urlConnection.inputStream
                                bitmap = BitmapFactory.decodeStream(input)
                            } catch (e: IOException) {
                                e.printStackTrace()
                            }
                        }
                    }
                }
            }

            imgMeal.setImageBitmap(bitmap)
        }


    }
}