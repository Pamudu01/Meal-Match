package com.example.meal_match

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


@Dao
interface MealsDAO {

    // Inserts one or more meals into the Meals table.
    @Insert
    suspend fun insert(vararg meals: Meals)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeals(vararg meals: Meals)

    // Gets all meals from the Meals table.
    @Query("SELECT * FROM meals")
    suspend fun getAllMeals(): List<Meals>

    // Gets meals with a specified name from the Meals table.
    @Query("Select * From meals WHERE Meal LIKE :Meal")
    suspend fun loadAllByNames(Meal: String): List<Meals>

    // Gets the image URL for a specified meal from the Meals table.
    @Query("SELECT MealThumb FROM meals WHERE Meal = :mealName")
    suspend fun getMealImage(mealName: String): String?


}

