package com.example.meal_match

import androidx.room.Database
import androidx.room.RoomDatabase

//Database for the meals
@Database(entities = [Meals::class], version = 1)
abstract class MealsDatabase : RoomDatabase() {
    abstract fun mealsDAO() : MealsDAO
}