package com.example.meal_match

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "meals")
data class Meals(

    // Data class representing the meals entity with columns

    //name of  the meal
    @ColumnInfo(name = "Meal") val Meal:String?,
    //drink option
    @ColumnInfo (name = "DrinkAlternate") val DrinkAlternate:String?,
    //category of the meal
    @ColumnInfo (name = "Category") val Category:String?,
    //country the meal originates from
    @ColumnInfo (name = "Area") val Area:String?,
    //instructions for cooking the meal
    @ColumnInfo (name = "Instructions") val Instructions:String?,
    //image of the meal
    @ColumnInfo (name = "MealThumb") val MealThumb:String?,
    @ColumnInfo (name = "Tags") val Tags:String?,
    //YouTube URL of a video showing how to cook the meal
    @ColumnInfo (name = "Youtube") val Youtube:String?,
    //ingredients needed to cook the meal
    @ColumnInfo (name = "Ingredient1") val Ingredient1:String?,
    @ColumnInfo (name = "Ingredient2") val Ingredient2:String?,
    @ColumnInfo (name = "Ingredient3") val Ingredient3:String?,
    @ColumnInfo (name = "Ingredient4") val Ingredient4:String?,
    @ColumnInfo (name = "Ingredient5") val Ingredient5:String?,
    @ColumnInfo (name = "Ingredient6") val Ingredient6:String?,
    @ColumnInfo (name = "Ingredient7") val Ingredient7:String?,
    @ColumnInfo (name = "Ingredient8") val Ingredient8:String?,
    @ColumnInfo (name = "Ingredient9") val Ingredient9:String?,
    @ColumnInfo (name = "Ingredient10") val Ingredient10:String?,
    //amount of each ingredient needed
    @ColumnInfo (name = "Measure1") val Measure1:String?,
    @ColumnInfo (name = "Measure2") val Measure2:String?,
    @ColumnInfo (name = "Measure3") val Measure3:String?,
    @ColumnInfo (name = "Measure4") val Measure4:String?,
    @ColumnInfo (name = "Measure5") val Measure5:String?,
    @ColumnInfo (name = "Measure6") val Measure6:String?,
    @ColumnInfo (name = "Measure7") val Measure7:String?,
    @ColumnInfo (name = "Measure8") val Measure8:String?,
    @ColumnInfo (name = "Measure9") val Measure9:String?,
    @ColumnInfo (name = "Measure10") val Measure10:String?,
    //source of the meal recipe
    @ColumnInfo (name = "Source") val Source:String?,
    //URL of the image source
    @ColumnInfo (name = "ImageSource") val ImageSource:String?,
    @ColumnInfo (name = "CreativeCommonsConfirmed") val CreativeCommonsConfirmed:String?,
    @ColumnInfo (name = "dateModified") val dateModified:String?,
){
    @PrimaryKey(autoGenerate = true)
    var id:Int =0
}
