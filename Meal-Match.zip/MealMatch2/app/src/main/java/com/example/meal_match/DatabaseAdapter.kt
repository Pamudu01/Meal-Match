package com.example.meal_match

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DatabaseAdapter(private val meals:List<Meals>): RecyclerView.Adapter<DatabaseAdapter.MealViewHolder>() {


    //Will be called when a new ViewHolder is needed
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val itemView = inflater.inflate(R.layout.food_template, parent, false)
        return MealViewHolder(itemView)
    }

    override fun getItemCount(): Int =meals.size

    // This is called to display the data at a specific position
    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        val meal=meals[position]
        holder.bind(meal)
    }

    //holds the views of each item in the RecyclerView
    inner class MealViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        private val txtMealName=itemView.findViewById<TextView>(R.id.txt_db_name)
        private val txtMealCategory=itemView.findViewById<TextView>(R.id.txt_db_category)
        private val txtMealArea=itemView.findViewById<TextView>(R.id.txt_db_area)
        private val txtMealTags=itemView.findViewById<TextView>(R.id.txt_db_tag)
        private val txtMealYoutube=itemView.findViewById<TextView>(R.id.txt_db_youtube)
        private val txtMealThumb = itemView.findViewById<TextView>(R.id.txt_MealThumb)
        private val txtMealDrink = itemView.findViewById<TextView>(R.id.txt_db_Drink)




        //binds the data of a Meal to the views of an item
        @SuppressLint("SetTextI18n")
        fun bind(meal: Meals) {
            txtMealName.text = meal.Meal
            txtMealCategory.text = "Category - ${meal.Category}"
            txtMealArea.text = "Area - ${meal.Area}"
            txtMealTags.text = "Tags - ${meal.Tags}"
            txtMealYoutube.text = "YouTube- ${meal.Youtube}\n"
            txtMealThumb.text = "Image Url-${meal.MealThumb}\n"
            txtMealDrink.text = "Drink -${meal.dateModified}\n"
        }


    }
}