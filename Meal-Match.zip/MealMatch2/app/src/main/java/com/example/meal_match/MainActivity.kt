package com.example.meal_match

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import java.io.File

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //path for the app's database file and delete it
        val data: File = Environment.getDataDirectory()
        val currentDBPath = "/data/com.example.meal_match/databases/mealsdb"
        val currentDB = File(data, currentDBPath)
        val deleted = SQLiteDatabase.deleteDatabase(currentDB)

        //set click listeners to launch activities to the buttons
        val btn_add_Data = findViewById<Button>(R.id.add_meal_btn)
        btn_add_Data.setOnClickListener{

            val DBintent = Intent(this,MealsDatabaseActivity::class.java)
            startActivity(DBintent)
        }

        val btn_retrieve_n_save = findViewById<Button>(R.id.srch_ing_btn)
        btn_retrieve_n_save.setOnClickListener {

            val RetnSvIntent = Intent(this,Retrieve_Save::class.java)
            startActivity(RetnSvIntent)
        }

        val btn_search_meals = findViewById<Button>(R.id.srch_mls_btn)
        btn_search_meals.setOnClickListener {
            val searchIntent = Intent(this,SearchForMealsActivity::class.java)
            startActivity(searchIntent)
        }


        val btn_search_mealsFromWeb = findViewById<Button>(R.id.srch_frm_web_btn)
        btn_search_mealsFromWeb.setOnClickListener {
            val searchFromWebIntent = Intent (this,SearchFromWebServise::class.java)
            startActivity(searchFromWebIntent)
        }

    }
}