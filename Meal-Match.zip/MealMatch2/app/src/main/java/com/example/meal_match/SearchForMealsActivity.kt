package com.example.meal_match

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking


class SearchForMealsActivity : AppCompatActivity() {

    //Variables for search button, search bar, adapter, and list of meals
    private lateinit var searchForMealsBut:Button
    private lateinit var searchBar:EditText
    private lateinit var foodAdapter:Adapter
    private  var meal:List<Meals> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_for_meals)


        val db = Room.databaseBuilder(this, MealsDatabase::class.java,
            "mealsdb").build()
        val mealDao =db.mealsDAO()


        //search button and search bar views from the layout
        searchForMealsBut =findViewById(R.id.srch_for_mls_btn)
        searchBar=findViewById(R.id.srch_meal)

        //click listener for search button
        searchForMealsBut.setOnClickListener {

            // If search bar text is not null and not empty, call loadMeals function
            if(searchBar.text?.toString()!=null && searchBar.text?.toString()!!.trim().isNotEmpty()){
                loadMeals("%${searchBar.text}%",mealDao)
            }

        }
    }

    //function to loads meals from the database using the provided searchText
    private fun loadMeals(edtText:String,mealDao:MealsDAO){
        runBlocking {
            launch {

                try {
                    meal = mealDao.loadAllByNames(edtText)

                } catch (e: Exception) {
                    //Display message  if an error has happened
                    Log.e("Error", "Error accessing database: ${e.message}")
                }
            }
        }

        //checking if the food array is empty
        if(meal.isNotEmpty()) {
            foodAdapter = Adapter(meal)
            val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = foodAdapter
        }else{
            Toast.makeText(this,"No entries with this name",Toast.LENGTH_SHORT).show()
        }
    }

    //when the activity is about to be destroyed, It saves the text in the search bar to the provided Bundle
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putString("TEXT",searchBar.text.toString())
    }


    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        // Restore the text of the searchBar EditText from the saved instance state
        var edtText=savedInstanceState.getString("TEXT")
        searchBar.setText(edtText)
        edtText="%${edtText}%"


        val db = Room.databaseBuilder(this, MealsDatabase::class.java,
            "myDatabase").build()
        val foodDao =db.mealsDAO()

        // Show a toast message with the search query string
        Toast.makeText(this,"$edtText",Toast.LENGTH_SHORT).show()
        loadMeals(edtText,foodDao)

        // Show a toast message with the number of meals loaded from the database
        Toast.makeText(this,"${meal.size}",Toast.LENGTH_SHORT).show()
    }
}