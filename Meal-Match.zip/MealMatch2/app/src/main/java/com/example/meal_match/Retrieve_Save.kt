package com.example.meal_match

import android.os.AsyncTask
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.URL

class Retrieve_Save: AppCompatActivity() {

    //views to be used in the layout
    private lateinit var ingredientEditText: EditText
    private lateinit var retrieveMeals: View
    private lateinit var retriewMealsPreview: TextView
    private lateinit var saveMeals: Button

    private var ingridients = mutableListOf<Meals>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_retrieve_save)

        // Build the Room database and initialize the DAO
        val db = Room.databaseBuilder(this,MealsDatabase::class.java,"mealsdb").build()
        val mealsdao = db.mealsDAO()

        ingredientEditText = findViewById(R.id.webSrchEditText)
        retrieveMeals = findViewById(R.id.rtrv_mls_btn)
        retriewMealsPreview = findViewById(R.id.retriewMealsPreview)
        saveMeals = findViewById(R.id.sv_mls_db_btn)


        //OnClickListener for the retrieveMealsButton
        retrieveMeals.setOnClickListener {
            val ingredient = ingredientEditText.text.toString()
            FetchMealsTask().execute(ingredient)

        }

        //OnClickListener for the saveMealsButton
        saveMeals.setOnClickListener {
            runBlocking {
                launch {
                    for(i in ingridients){
                        mealsdao.insertMeals(i)
                    }
                }
            }
        }
    }


    inner class FetchMealsTask : AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg params: String?): String {
            val ingredient = params[0] ?: return ""

            val url = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=$ingredient")
            val result = url.readText()
            println(result)
            return result
        }


        override fun onPostExecute(result: String) {
            super.onPostExecute(result)

            //StringBuilder to store the meal details
            val mealDetails = StringBuilder()

            val jsonObject = JSONObject(result)
            val mealsArray = jsonObject.getJSONArray("meals")

            for (i in 0 until mealsArray.length()) {
                val mealObject = mealsArray.getJSONObject(i)

                //extract various fields from the meal object
                val mealName = mealObject.getString("strMeal")
                val drinkAlternate = mealObject.getString("strDrinkAlternate")
                val category = mealObject.getString("strCategory")
                val area = mealObject.getString("strArea")
                val instructions = mealObject.getString("strInstructions")
                val tags = mealObject.getString("strTags")
                val youtube = mealObject.getString("strYoutube")
                val ingredient1 = mealObject.getString("strIngredient1")
                val ingredient2 = mealObject.getString("strIngredient2")
                val ingredient3 = mealObject.getString("strIngredient3")
                val ingredient4 = mealObject.getString("strIngredient4")
                val ingredient5 = mealObject.getString("strIngredient5")
                val ingredient6 = mealObject.getString("strIngredient6")
                val ingredient7 = mealObject.getString("strIngredient7")
                val ingredient8 = mealObject.getString("strIngredient8")
                val ingredient9 = mealObject.getString("strIngredient9")
                val ingredient10 = mealObject.getString("strIngredient10")
                val measure1 = mealObject.getString("strMeasure1")
                val measure2 = mealObject.getString("strMeasure2")
                val measure3 = mealObject.getString("strMeasure3")
                val measure4 = mealObject.getString("strMeasure4")
                val measure5 = mealObject.getString("strMeasure5")
                val measure6 = mealObject.getString("strMeasure6")
                val measure7 = mealObject.getString("strMeasure7")
                val measure8 = mealObject.getString("strMeasure8")
                val measure9 = mealObject.getString("strMeasure9")
                val measure10 = mealObject.getString("strMeasure10")
                val mealthumb = mealObject.getString("strMealThumb")
                val creativeCommonsConfirmed = mealObject.getString("strCreativeCommonsConfirmed")
                val dateModified = mealObject.getString("dateModified")
                val imageSource = mealObject.getString("strImageSource")
                val source = mealObject.getString("strSource")

                //  string containing all the meal details
                mealDetails.append(
                    "Meal: $mealName\nCategory: $category\n DrinkAlternate : $drinkAlternate\n Area: $area\nInstructions:  $instructions\nTags: $tags\nYoutube: $youtube\nIngredient1: $ingredient1\nIngredient2: $ingredient2\nIngredient3: $ingredient3\nIngredient4: $ingredient4\nIngredient5: $ingredient5\nIngredient6: $ingredient6\nIngredient7: $ingredient7\nIngredient8: $ingredient8\nIngredient9: $ingredient9\nIngredient10: $ingredient10\nMeasure1: $measure1\n" +
                            "Measure2: $measure2\nMeasure3: $measure3\nMeasure4: $measure4\nMeasure5: $measure5\nMeasure6: $measure6\nMeasure7: $measure7\nMeasure8: $measure8\nMeasure9: $measure9\nMeasure10: $measure10\n creativeCommonsConfirmed :$creativeCommonsConfirmed \n source:$source \nMealthumb : $mealthumb \nModified Date : $dateModified \nImage Source: $imageSource"
                )
                mealDetails.append("\n")

                var Meal1 = Meals(
                    mealName,
                    drinkAlternate,
                    category,
                    area,
                    instructions,
                    tags,
                    youtube,
                    ingredient1,
                    ingredient2,
                    ingredient3,
                    ingredient4,
                    ingredient5,
                    ingredient6,
                    ingredient7,
                    ingredient8,
                    ingredient9,
                    ingredient10,
                    measure1,
                    measure2,
                    measure3,
                    measure4,
                    measure5,
                    measure6,
                    measure7,
                    measure8,
                    measure9,
                    measure10,
                    mealthumb,
                    creativeCommonsConfirmed,
                    dateModified,
                    imageSource,
                    source
                )
                ingridients.add(Meal1)
            }
                retriewMealsPreview.text = mealDetails.toString()
                //println(mealDetails)
            }

        }
    }

